# A.
first = 7
second = 44.3
print(first + second)
print(first * second)
print(first / second)

# B.

a = 9
b = 8
c = 15

# C.

'''No. both are containing the same type and same value'''

'''The problem is that you've added Number to String.
The other option is print("result is: ", my_number) 
or print("result is: " + str(my_number)) '''

# D.
'''7'''

# E
x = int()
y = int()
if x > y:
    print("BIG")
elif x < y:
    print("small")

# F
x = int(input("Enter the season number:"))
if x == 1:
    print("summer")
elif x == 2:
    print("winter")
elif x == 3:
    print("fall")
elif x == 4:
    print("sprint")

# Challenge

a = 8
b = "123"
print(a + int(b))
print(str(a) + b)